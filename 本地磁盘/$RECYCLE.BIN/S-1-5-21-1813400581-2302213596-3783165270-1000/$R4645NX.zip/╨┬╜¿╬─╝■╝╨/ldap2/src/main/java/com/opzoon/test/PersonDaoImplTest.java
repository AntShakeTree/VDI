package com.opzoon.test;

import org.junit.Test;

import com.opzoon.dao.PersonDao;
import com.opzoon.dao.PersonDao;
import com.opzoon.entity.Person;

public class PersonDaoImplTest {
    private PersonDao personDao;
    public void setPersonDaoImpl(PersonDao personDao) {
        this.personDao = personDao;
    }
 
   
}
