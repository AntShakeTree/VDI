package com.opzoon.dao;

import java.util.ArrayList;
import java.util.List;

import javax.naming.directory.Attributes;
import javax.naming.directory.BasicAttribute;
import javax.naming.directory.BasicAttributes;



import javax.naming.directory.DirContext;
import javax.naming.directory.ModificationItem;

import org.springframework.ldap.NameNotFoundException;
import org.springframework.ldap.core.DistinguishedName;
import org.springframework.ldap.core.LdapTemplate;
import org.springframework.ldap.filter.AndFilter;
import org.springframework.ldap.filter.EqualsFilter;
import org.springframework.stereotype.Component;

import com.opzoon.entity.MyLdapTemplate;
import com.opzoon.entity.Person;
import com.opzoon.mapper.PersonAttributeMapper;

@Component
public class PersonDao{
   private LdapTemplate ldapTemplate;    
    /*����*/
    public void addOnePerson(Person person){
        ldapTemplate = MyLdapTemplate.ldapTemplate;
        Attributes attr = new BasicAttributes();
        attr.put("objectclass", "person");
        attr.put("cn", person.getUserId());  
        attr.put("sn", person.getUsername()); 
  
  
        if (person.getUserPassword() != null  
                && person.getUserPassword().length() > 0) {  
            attr.put("userPassword", person.getUserPassword());  
        }  
   
        if (person.getTelephoneNumber() != null   
                && person.getTelephoneNumber().length() > 0) {  
            attr.put("telephoneNumber", person.getTelephoneNumber());  
        }
        
        if (person.getGroupName() != null   
                && person.getGroupName().length() > 0) {  
            attr.put("description", person.getGroupName());  
        }
        ldapTemplate.bind(getDn(person), null, attr);
        
    }
    
    public Person getPersonDetail(Person person) {
         LdapTemplate ldapTemplate = MyLdapTemplate.ldapTemplate;
        try {  
            //ldapTeplate��lookup�����Ǹ���dn���в�ѯ���˲�ѯ��Ч�ʳ���  
            Person ua = (Person)   
                ldapTemplate.lookup(getDn(person),  
                        new PersonAttributeMapper());  
            return ua;  
        } catch (NameNotFoundException e) {  
            return null;  
        }  
    } 
    
    /*��ѯ*/
    public List<Person> getPersonList(Person person) {
        ldapTemplate = MyLdapTemplate.ldapTemplate;
       
        List<Person> list = new ArrayList<Person>();  
        
        //��ѯ��������  
        AndFilter andFilter = new AndFilter();  
        andFilter.and(new EqualsFilter("objectclass", "person"));          
        if (person.getUserId() != null  
                && person.getUserId().length() > 0) {  
            andFilter.and(new EqualsFilter("cn", person.getUserId()));  
        }  
        if (person.getUsername() != null  
                && person.getUsername().length() > 0) {  
            andFilter.and(new EqualsFilter("sn", person.getUsername()));  
        }     
  
        if (person.getUserPassword() != null  
                && person.getUserPassword().length() > 0) {  
            andFilter.and(new EqualsFilter("userPassword", person.getUserPassword()));  
        }  
 
        if (person.getTelephoneNumber() != null   
                && person.getTelephoneNumber().length() > 0) {  
            andFilter.and(new EqualsFilter("telephoneNumber", person.getTelephoneNumber()));  
        }
        
        if(person.getGroupName() != null
                && person.getGroupName().length() > 0){
            andFilter.and(new EqualsFilter("description", person.getGroupName()));
        }
        //search�Ǹ��ݹ����������в�ѯ����һ�������Ǹ��ڵ��dn������Ϊ�գ���Ϊ��ʱ��ѯЧ�ʸ���    
        
    
        list = ldapTemplate.search("", andFilter.encode(),  
                new PersonAttributeMapper());  
        return list;  
    }  
    
    /*ɾ��*/
    public void deleteOnePerson(Person person) {
        ldapTemplate = MyLdapTemplate.ldapTemplate;
        ldapTemplate.unbind(getDn(person));  
    } 
    
    /*�޸�*/
    public void updateOnePerson(Person person) {
        ldapTemplate = MyLdapTemplate.ldapTemplate;
        if (person == null || person.getUserId() == null   
                || person.getUserId().length() <= 0) {  
            return;  
        }  
        List<ModificationItem> mList = new ArrayList<ModificationItem>();  
          
        mList.add(new ModificationItem(DirContext.REPLACE_ATTRIBUTE,  
                new BasicAttribute("sn",person.getUsername())));       
        mList.add(new ModificationItem(DirContext.REPLACE_ATTRIBUTE,  
                new BasicAttribute("telephoneNumber",person.getTelephoneNumber())));  
        mList.add(new ModificationItem(DirContext.REPLACE_ATTRIBUTE,  
                new BasicAttribute("userPassword",person.getUserPassword())));  
          
        if (mList.size() > 0) {  
            ModificationItem[] mArray = new ModificationItem[mList.size()];  
            for (int i = 0; i < mList.size(); i++) {  
                mArray[i] = mList.get(i);  
            }  
            //modifyAttributes �������޸Ķ���Ĳ�������rebind����������Ҫ����  
            ldapTemplate.modifyAttributes(this.getDn(person), mArray);  
        }  
    } 
   
    private DistinguishedName getDn(Person person) {  
        //�õ���Ŀ¼��Ҳ���������ļ������õ�ldap�ĸ�Ŀ¼  
        DistinguishedName newContactDN = new DistinguishedName();  
        // ����cn����ʹ�ø�����¼��dnΪ"cn=cn,��Ŀ¼",����"cn=abc,dc=testdc,dc=com"
        newContactDN.append("ou", person.getGroupName());
        newContactDN.add("cn", person.getUserId());
       
        return newContactDN;  
    }
}
