package com.opzoon.entity;


import org.springframework.ldap.core.AuthenticationSource;
import org.springframework.ldap.core.LdapTemplate;
import org.springframework.ldap.core.support.LdapContextSource;

public class MyLdapTemplate {
    
    public static LdapTemplate ldapTemplate; 
    public static void setLdapTemplate(String url,String base,final String userDn, final String password){   

        LdapContextSource ldapContextSource = new LdapContextSource();
        ldapContextSource.setCacheEnvironmentProperties(false);
        ldapContextSource.setUrl(url);
        ldapContextSource.setBase(base);
        ldapContextSource.setUserDn(userDn);
        ldapContextSource.setPassword(password);
        ldapContextSource.setAuthenticationSource(new AuthenticationSource() {
            
            @Override
            public String getPrincipal() {
                // TODO Auto-generated method stub
                return userDn;
            }
            
            @Override
            public String getCredentials() {
                // TODO Auto-generated method stub
                return password;
            }
        });
        ldapTemplate = new LdapTemplate(ldapContextSource);        
    }
}
