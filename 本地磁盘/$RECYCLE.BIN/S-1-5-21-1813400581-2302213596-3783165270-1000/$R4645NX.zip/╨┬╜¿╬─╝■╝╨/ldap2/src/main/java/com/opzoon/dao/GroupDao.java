package com.opzoon.dao;

import java.util.ArrayList;
import java.util.List;

import javax.naming.directory.Attributes;
import javax.naming.directory.BasicAttributes;

import org.springframework.ldap.core.DistinguishedName;
import org.springframework.ldap.core.LdapTemplate;
import org.springframework.ldap.filter.AndFilter;
import org.springframework.ldap.filter.EqualsFilter;
import org.springframework.stereotype.Component;

import com.opzoon.entity.Group;
import com.opzoon.entity.MyLdapTemplate;
import com.opzoon.mapper.GroupAttributeMapper;
import com.opzoon.mapper.PersonAttributeMapper;

@Component
public class GroupDao {
    private LdapTemplate ldapTemplate;
   
    public void addGroup(Group group){
        ldapTemplate = MyLdapTemplate.ldapTemplate;
        Attributes attr = new BasicAttributes();
        attr.put("objectclass", "organizationalUnit");
        attr.put("ou", group.getGroupName());
        ldapTemplate.bind(getDn(group.getGroupName()), null, attr);
    }
    
    public List<Group> getGroups(){
        ldapTemplate = MyLdapTemplate.ldapTemplate;
        List<Group> groups = new ArrayList<Group>();
        AndFilter andFilter = new AndFilter();  
        andFilter.and(new EqualsFilter("objectclass", "organizationalUnit"));
        groups = ldapTemplate.search("", andFilter.encode(),  
                new GroupAttributeMapper());  
        return groups;
    }
    
    private DistinguishedName getDn(String ou) {  
        //�õ���Ŀ¼��Ҳ���������ļ������õ�ldap�ĸ�Ŀ¼  
        DistinguishedName newContactDN = new DistinguishedName();  
        // ����cn����ʹ�ø�����¼��dnΪ"cn=cn,��Ŀ¼",����"cn=abc,dc=testdc,dc=com"  
        newContactDN.add("ou", ou);      
        return newContactDN;  
    }
}
