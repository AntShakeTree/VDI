package com.opzoon.mapper;

import javax.naming.NamingException;
import javax.naming.directory.Attributes;

import org.springframework.ldap.core.AttributesMapper;

import com.opzoon.entity.Group;

public class GroupAttributeMapper implements AttributesMapper<Group>{

    @Override
    public Group mapFromAttributes(Attributes attr) throws NamingException {
        Group group = new Group();
        group.setGroupName((String)attr.get("ou").get());
        return group;
    }

}
