package com.opzoon.controller;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.opzoon.dao.GroupDao;
import com.opzoon.dao.PersonDao;
import com.opzoon.entity.Group;
import com.opzoon.entity.LdapSource;
import com.opzoon.entity.Message;
import com.opzoon.entity.MyLdapTemplate;
import com.opzoon.entity.Person;
import com.opzoon.init.RootInit;

@Controller
@RequestMapping("/")
public class LdapController {
    
    @Autowired
    private PersonDao personDao;
    @Autowired
    private GroupDao groupDao; 
    
    @RequestMapping(value="/setldap" , method=RequestMethod.POST)
    public @ResponseBody Message setLdapController(@RequestBody LdapSource ldapSource){
        
        MyLdapTemplate.setLdapTemplate(ldapSource.getUrl(),
                ldapSource.getBase(), ldapSource.getUserDn(), ldapSource.getPassword());
        //RootInit.init(ldapSource);
        Message message = new Message();      
        message.setCode(0);
        message.setMessaage("set LdapTemplate success");
        return message;
    }
    
    @RequestMapping(value="/addgroup" , method=RequestMethod.POST)
    public @ResponseBody Message addGroupController(@RequestBody Group group){
       Message message = new Message();
       if(group.getGroupName()==null||group.getGroupName().length()==0){
           message.setCode(1);
           message.setMessaage("groupname error");
           return message;
       }
       groupDao.addGroup(group);
       message.setCode(0);
       message.setMessaage("add group success");
       return message;
    }
    
    @RequestMapping(value="/getgroups" , method=RequestMethod.POST)
    public @ResponseBody List<Group> getGroupsController(@RequestBody Group group){
       return groupDao.getGroups();
    }
    
    @RequestMapping(value="/addperson" , method=RequestMethod.POST)
    public @ResponseBody Message addPersonController(@RequestBody Person person){
       Message message = new Message();
       if(person.getUserId()==null||person.getUserId().length()==0
               ||person.getUsername()==null){
           message.setCode(1);
           message.setMessaage("cn or sn error");
           return message;
       }
       personDao.addOnePerson(person);
       message.setCode(0);
       message.setMessaage("add person success");
       return message;
    }
    
    @RequestMapping(value="/getoneperson" , method=RequestMethod.POST)
    public @ResponseBody Person getOnePersonsController(@RequestBody Person person){      
        return personDao.getPersonDetail(person);
    }
    
    @RequestMapping(value="/getpersons" , method=RequestMethod.POST)
    public @ResponseBody List<Person> getPersonsController(@RequestBody Person person){
        return personDao.getPersonList(person);        
    }
    
    @RequestMapping(value="/deleteperson" , method=RequestMethod.POST)
    public  @ResponseBody Message deletePersonController(@RequestBody Person person){
        Message message = new Message();
        personDao.deleteOnePerson(person);
        message.setCode(0);
        message.setMessaage("delete person success");
        return message;
        
    }
    
    @RequestMapping(value="/updateperson" , method=RequestMethod.POST)
    public @ResponseBody Message updatePersonController(@RequestBody Person person){
       Message message = new Message();
       personDao.updateOnePerson(person);
       message.setCode(0);
       message.setMessaage("update person success");
       return message;
    }
}
