package com.opzoon.mapper;

import javax.naming.NamingException;
import javax.naming.directory.Attributes;

import org.codehaus.jackson.Base64Variant;
import org.springframework.ldap.core.AttributesMapper;



import com.opzoon.entity.Person;

public class PersonAttributeMapper implements AttributesMapper<Person>{

    @Override
    public Person mapFromAttributes(Attributes attr) throws NamingException {
        Person person = new Person();  
        person.setUsername((String)attr.get("sn").get());  
        person.setUserId((String)attr.get("cn").get());
        if (attr.get("description") != null) { 
            person.setGroupName((String)attr.get("description").get());
        }       
        if (attr.get("userPassword") != null) { 
            byte[] b = (byte[])attr.get("userPassword").get(0); 
            String userPassword = new String(b);
            person.setUserPassword(userPassword);
        }  
        if (attr.get("telephoneNumber") != null) {  
            person.setTelephoneNumber((String)attr.get("telephoneNumber").get());  
        }          
        return person;  
    } 

    
}
