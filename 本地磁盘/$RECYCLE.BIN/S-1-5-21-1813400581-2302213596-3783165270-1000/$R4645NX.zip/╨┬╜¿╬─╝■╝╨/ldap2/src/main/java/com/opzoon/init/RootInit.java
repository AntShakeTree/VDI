package com.opzoon.init;

import java.util.ArrayList;
import java.util.List;

import javax.naming.directory.Attributes;
import javax.naming.directory.BasicAttribute;
import javax.naming.directory.BasicAttributes;
import javax.naming.directory.DirContext;
import javax.naming.directory.ModificationItem;

import org.springframework.ldap.core.DistinguishedName;
import org.springframework.ldap.core.LdapTemplate;

import com.opzoon.entity.LdapSource;
import com.opzoon.entity.MyLdapTemplate;
import com.opzoon.entity.Person;

public class RootInit {
    public static void init(LdapSource ldapSource){
        LdapTemplate ldapTemplate = MyLdapTemplate.ldapTemplate;
   /*     Attributes attr = new BasicAttributes();
        attr.put("objectclass", "top");
        attr.put("objectclass", "dcobject");
        attr.put("objectclass", "organization");
        attr.put("dc", "opzoon");
        attr.put("dc", "com");
        attr.put("o", ldapSource.getOrganization()); 
        ldapTemplate.bind(getDn(), null, attr);*/
        List<ModificationItem> mList = new ArrayList<ModificationItem>();  
        
        mList.add(new ModificationItem(DirContext.REPLACE_ATTRIBUTE,  
                new BasicAttribute("objectclass","top")));       
        mList.add(new ModificationItem(DirContext.REPLACE_ATTRIBUTE,  
                new BasicAttribute("objectclass","dcobject")));  
        mList.add(new ModificationItem(DirContext.REPLACE_ATTRIBUTE,  
                new BasicAttribute("objectclass","organization")));
        mList.add(new ModificationItem(DirContext.REPLACE_ATTRIBUTE,  
                new BasicAttribute("dc","opzoon")));
        mList.add(new ModificationItem(DirContext.REPLACE_ATTRIBUTE,  
                new BasicAttribute("o",ldapSource.getOrganization())));          
        if (mList.size() > 0) {  
            ModificationItem[] mArray = new ModificationItem[mList.size()];  
            for (int i = 0; i < mList.size(); i++) {  
                mArray[i] = mList.get(i);  
            }  
            //modifyAttributes �������޸Ķ���Ĳ�������rebind����������Ҫ����  
            ldapTemplate.modifyAttributes(getDn(), mArray);  
        }  
       
    }
    private static DistinguishedName getDn() {  
        //�õ���Ŀ¼��Ҳ���������ļ������õ�ldap�ĸ�Ŀ¼  
        DistinguishedName newContactDN = new DistinguishedName();  
        // ����cn����ʹ�ø�����¼��dnΪ"cn=cn,��Ŀ¼",����"cn=abc,dc=testdc,dc=com"          
        return newContactDN;  
    }
}
