package com.opzoon.entity;

public class LdapSource {
    String url;
    String base;
    String userDn;
    String password;
    String organization;
    public String getUrl() {
        return url;
    }
    public void setUrl(String url) {
        this.url = url;
    }
    public String getBase() {
        return base;
    }
    public void setBase(String base) {
        this.base = base;
    }
    public String getUserDn() {
        return userDn;
    }
    public void setUserDn(String userDn) {
        this.userDn = userDn;
    }
    public String getPassword() {
        return password;
    }
    public void setPassword(String password) {
        this.password = password;
    }
    public String getOrganization() {
        return organization;
    }
    public void setOrganization(String organization) {
        this.organization = organization;
    }
    
    
}
